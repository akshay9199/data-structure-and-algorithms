package org.learning;

public class DisjointSet {
    static int[] rank;
    static int[] parent;

    static int[] size;

    public DisjointSet(int n){
        rank = new int[n];
        parent = new int[n];
        for(int i=0;i<rank.length;i++){
            parent[i] = i;
            rank[i] = 0;
            size[i] =1;
        }
    }

    public static int findParent(int i){
        if(parent[i] == i){
            return i;
        }
        return parent[i] = findParent(parent[i]);
    }

    public static void unionByRank(int u,int v) {
        int uParent = findParent(u);
        int vParent = findParent(v);
        if(uParent != vParent) {
            if (rank[uParent] > rank[vParent]) {
                parent[vParent] = uParent;
            }
            else if (rank[uParent] < rank[vParent]) {
                parent[uParent] = vParent;
            }
            else {
                parent[uParent] = vParent;
                rank[vParent] += 1;
            }
        }
    }

    public static void unionBySize(int u,int v){
        int uParent = findParent(u);
        int vParent = findParent(v);
        if(uParent != vParent){
            if(size[uParent] > size[vParent]){
                parent[vParent] = uParent;
                size[uParent] += size[vParent];
            }
            else if(size[uParent] < size[vParent]){
                parent[uParent] = vParent;
                size[vParent] += size[uParent];
            }
            else{
                parent[uParent] = vParent;
                size[vParent] += size[uParent];
            }
        }
    }

    public static void main(String[] args) {
        DisjointSet ds = new DisjointSet(7);
        ds.unionByRank(1,2);
        System.out.println(findParent(3) == findParent(2));
        ds.unionByRank(2,3);
        System.out.println(findParent(3) == findParent(2));
        ds.unionByRank(4,5);
        ds.unionByRank(6,0);
        System.out.println(parent[1]);
        System.out.println(parent[2]);
        System.out.println(parent[3]);
    }
}
