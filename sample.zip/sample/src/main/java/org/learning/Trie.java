package org.learning;

class Node{
    Node []links = new Node[26];
    boolean flag;
}
public class Trie{
    Node root;
    public Trie(){
        root = new Node();
    }
    public void insertText(String word){
        Node node = root;
        for(int i=0;i<word.length();i++){
            if(node.links[word.charAt(i)-'a'] == null){
                node.links[word.charAt(i)-'a'] = new Node();
            }
            node = node.links[word.charAt(i) -'a'];
        }
        node.flag = true;
    }
 public  boolean checkWord(String word){
        Node node = root;
        for(int i=0;i<word.length();i++) {
            if (node.links[word.charAt(i) - 'a'] == null) {
                return false;
            }
            node = node.links[word.charAt(i) - 'a'];
        }
            if(node.flag == true){
                return true;

            }
        return false;
 }

 public boolean checkWordWithPrefix(String word){
        Node node = root;
        for(int i=0;i<word.length();i++){
            if(node.links[word.charAt(i)-'a'] == null){
                return false;
            }
            node = node.links[word.charAt(i)-'a'];
           // return true;
        }
        return true;
 }

 public static  void main(String args[]){
        Trie t  = new Trie();
        t.insertText("sample");
     System.out.println(t.checkWord("samplee"));
    System.out.println(t.checkWord("sample"));
     System.out.println(t.checkWordWithPrefix("samp"));
     System.out.println(t.checkWordWithPrefix("san"));
     System.out.println(t.checkWordWithPrefix("sample"));


 }

}