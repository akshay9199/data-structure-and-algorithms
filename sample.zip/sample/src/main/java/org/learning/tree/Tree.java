package org.learning.tree;

import java.util.*;

class Node{
    int value;
    Node left;
    Node right;

    public Node(int value){
        this.value = value;
        left = null;
        right = null;
    }

}
public class Tree {
//      4
//    /   \
//   5     8
//  /  \
// 6     7
//        \
//         0
    public static void main(String[] args) {
    Node root = new Node(4);
    root.left = new Node(5);
    root.left.left = new Node(6);
    root.right = new Node(8);
    root.left.right = new Node(7);
    root.left.right.right = new Node(0);

   // exploreDFSWithIteration(root);

   // exploreBFSWithIteration(root);

    List<Integer> result = new ArrayList<>();

//    Queue<Node> queue = new LinkedList();
//    queue.add(root);
//    iterateTreeUsingBFSRecursion(queue,result);
//    System.out.println(result.toString());

//    Stack stack = new Stack();
//    stack.add(root);
//    iterateTreeUsingDFSRecursion(stack,result);
//    System.out.println(result.toString());

//        printInorder(root,result);
//        System.out.println("Inorder"+result.toString());

//        printPreOrder(root,result);
//        System.out.println("preorder"+result.toString());

//        printPostOrder(root,result);
//        System.out.println("printPostOrder"+result.toString());

        //System.out.println("Tree Sum is"+ treeSum(root));

       // System.out.println("Max num is"+ maxNum(root));

      //  System.out.println(isNumberInTree(root,6));

        root = new Node(9);
        root.left = new Node(6);
        root.left.left = new Node(5);
        root.left.right = new Node(8);
        root.right = new Node(20);
        root.right.right = new Node(24);
        root.right.left = new Node(16);
        root.right.left.left = new Node(23);

        //System.out.println(searchInBST(root,24));

        //System.out.println(findFloor(root,15));

        //System.out.println(findCeil(root,15));

       // leftView(root,result,0);
       // rightView(root,result,0);
        System.out.println(result);

    }

    public static void leftView(Node root,List<Integer> result,int currDep){
        if (root == null) return;
        if(currDep == result.size()) result.add(root.value);
        leftView(root.left,result,currDep+1);
        leftView(root.right,result,currDep+1);
    }

    public static void rightView(Node root,List<Integer> result,int currDep){
        if (root == null) return;
        if(result.size() == currDep) result.add(root.value);
        rightView(root.right,result,currDep+1);
        rightView(root.left,result,currDep+1);

    }


//    public static int findCeil(Node root,int val){
//        if (root == null) return Integer.MAX_VALUE;
//        if ( root.value == val) return root.value;
//        Node node = root.value > val ? root.left  : root.right;
//        return Math.min(root.value,findCeil(node,val));
//    }
//    public static int findFloor(Node root,int val){
//        if (root == null) return Integer.MAX_VALUE;
//        if ( root.value == val) return root.value;
//        Node node = root.value > val ? root.left  : root.right;
//        return Math.min(root.value,findFloor(node,val));
//    }

    public static boolean searchInBST(Node root,int val){
        if (root == null) return false;
        if (root.value == val) return true;
        Node node = root.value > val ? root.left : root.right;
        return searchInBST(node,val);
    }
    public static boolean isNumberInTree(Node root,int val){
        if(root == null) return false;
        if(root.value == val) return true;
        return isNumberInTree(root.left,val) || isNumberInTree(root.right,val);
    }


    public static int maxNum(Node root){
        if (root == null) return Integer.MIN_VALUE;
        return Math.max(Math.max(maxNum(root.left),maxNum(root.right)),root.value);
    }
    public static int treeSum(Node root){
        if(root == null ) return 0;

        int leftSum = treeSum(root.left);
        int rightSum = treeSum(root.right);
        return root.value + leftSum + rightSum;
    }


    public static void printPostOrder(Node root,List<Integer> result){
        if(root == null) return;
        printPostOrder(root.left,result);
        printPostOrder(root.right,result);
        result.add(root.value);
    }
    public static void printPreOrder(Node root,List<Integer> result){
        if(root == null) return;
        result.add(root.value);
        printPreOrder(root.left,result);
        printPreOrder(root.right,result);
    }
    public static void printInorder(Node root,List<Integer> result){
        if(root == null) return;
        printInorder(root.left,result);
        result.add(root.value);
        printInorder(root.right,result);
    }
    public static void iterateTreeUsingBFSRecursion(Queue<Node> queue,List<Integer> result){
        if (queue.size() == 0) return;
        Node temp = queue.poll();
        result.add(temp.value);
        if(temp.left != null) queue.add(temp.left);
        if(temp.right != null) queue.add(temp.right);
        iterateTreeUsingBFSRecursion(queue,result);
    }

    public static void iterateTreeUsingDFSRecursion(Stack stack,List<Integer> result){
        if (stack.size() == 0) return;
        Node temp = (Node) stack.pop();
        result.add(temp.value);
        if(temp.left != null)
            stack.add(temp.left);

        if(temp.right != null)
            stack.add(temp.right);
        iterateTreeUsingDFSRecursion(stack,result);
    }

    public static void exploreDFSWithIteration(Node root){
        if(root == null) return;
        Stack<Node> stack = new Stack();
        List<Integer> list = new ArrayList<>();
        stack.add(root);
        while(stack.size()>0){
            Node temp = stack.pop();
            list.add(temp.value);
            if(temp.left != null) stack.add(temp.left);
            if(temp.right != null) stack.add(temp.right);
        }
        System.out.println(list.toString());

    }

    public static void exploreBFSWithIteration(Node root){
        if (root == null) return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        List<Integer> list = new ArrayList<>();
        while(queue.size()>0){
           Node temp = queue.poll();
           list.add(temp.value);
            if(temp.left != null) queue.add(temp.left);
            if(temp.right != null) queue.add(temp.right);
        }
        System.out.println(list.toString());
    }
}
