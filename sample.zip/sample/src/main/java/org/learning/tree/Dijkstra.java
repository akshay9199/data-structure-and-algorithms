package org.learning.tree;
// Dijkstra's Algorithm in Java

import java.util.*;


public class Dijkstra {
    public static void main(String[] args) {
        List<List<Node1> > graph = new ArrayList<>();
        for (int i = 0; i < 6; i++)
            graph.add(new ArrayList<Node1>());

        graph.get(0).add(new Node1(1,2));

        graph.get(1).add(new Node1(0,2));
        graph.get(1).add(new Node1(5,1));
        graph.get(1).add(new Node1(2,3));

        graph.get(2).add(new Node1(1,3));
        graph.get(2).add(new Node1(3,4));
        graph.get(2).add(new Node1(4,5));

        graph.get(3).add(new Node1(2,4));
        graph.get(3).add(new Node1(5,2));

        graph.get(4).add(new Node1(2,4));
        graph.get(4).add(new Node1(5,6));

        graph.get(5).add(new Node1(0,1));
        graph.get(5).add(new Node1(3,2));
        graph.get(5).add(new Node1(4,6));

        findMinPath(graph, graph.size(), 1);

    }

    public static void findMinPath(List<List<Node1>> graph, int n, int s){
        int []distance = new int[n];
        for(int i=0;i<n;i++)
            distance[i] = Integer.MAX_VALUE;
        distance[s] = 0;
        PriorityQueue<Node1> queue = new PriorityQueue<Node1>(n,new Node1());
        queue.add(new Node1(s,0));
        while(!queue.isEmpty()){
            Node1 Node1 = queue.poll();
            for(Node1 neighbor:graph.get(Node1.value)){
                if( (distance[Node1.value] + neighbor.weight) <= distance[neighbor.value]){
                    distance[neighbor.value] = neighbor.weight + distance[Node1.value];
                    queue.add(new Node1(neighbor.value, neighbor.weight));
                }
            }
        }
        for (int i = 0; i < n; i++)
        {
            System.out.print( distance[i] + " ");
        }

    }


}

class Node1 implements Comparator<Node1> {
    int value;
    int weight;

    public Node1(){

    }
    public Node1(int v,int w){
        value = v;
        weight = w;
    }
    @Override
    public int compare(Node1 o1, Node1 o2) {
        if(o1.weight > o2.weight)
            return 1;
        if(o1.weight < o2.weight)
            return -1;
        return 0;
    }
}