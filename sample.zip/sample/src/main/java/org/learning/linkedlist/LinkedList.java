package org.learning.linkedlist;

import java.util.Stack;

class Node {
    int value;
    Node next;

    public Node(int val){
        this.value = val;
        next = null;
    }
}
public class LinkedList {
    public static void main(String[] args) {
        Node value1 = new Node(1);
        Node value2 = new Node(2);
        Node value3 = new Node(3);
        Node value4 = new Node(4);
        value1.next = value2;
        value2.next = value3;
        value3.next = value4;
        Node head = value1;

        //traverse(head);
        //traverseRecursion(head);
        System.out.println(findSum(head));
        System.out.println(findSumRecursion(head));
        System.out.println(findNum(head,4));
        System.out.println(findNum(head,6));
        System.out.println(findNumRecursion(head,4));
        System.out.println(findNumRecursion(head,6));
        System.out.println(reverse(head).value);
    }
public static void zippedList(Node head1, Node head2){
      Node tail = head1;
      Node current1 = head1.next;
      Node current2 = head2;
      int count =0;
      while(current2 != null && current1 != null) {
      if(count % 2 == 0){
        tail.next = current2;
        current2 = current2.next;
      }
      else {
          tail.next = current1;
          current1 = current1.next;
      }
      tail = tail.next;
      count += 1;
      }
      if(current1 != null ) tail.next = current1;
      if(current2 != null ) tail.next = current2;
}

    public static Node reverse(Node head){
        Node current = head;
        Node prev = null;
        while(current != null){
            Node next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        System.out.println(prev.value);
        return prev;
    }





    public static boolean findNumRecursion(Node head,int value){
        if(head == null) return false;
        if(head.value == value) return true;
        return findNumRecursion(head.next,value);
    }




    public static boolean findNum(Node head,int value){
        Node current = head;
        while(current != null){
            if(current.value == value){
                return true;
            }
            current = current.next;
        }
        return false;
    }




    public static int findSumRecursion(Node head){
        if(head == null) return 0;
        return head.value + findSumRecursion(head.next);
    }



    public static int findSum(Node head){
        Node current = head;
        int sum = 0;
        while(current != null){
            sum += current.value;
            current = current.next;
        }
        return sum;
    }





    public static void traverseRecursion(Node head){
        if(head == null) return;
        System.out.println(head.value);
        traverseRecursion(head.next);
    }





    public static void traverse(Node head){
        Node current = head;
        while(current != null){
            System.out.println(current.value);
            current = current.next;
        }
    }


}
