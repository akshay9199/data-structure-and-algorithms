package org.learning;

import java.util.LinkedList;


//INcorrect not working -------------------
public class ListNode {
    int val;
      ListNode next;
     ListNode() {}
    ListNode(int val) { this.val = val; }
   ListNode(int val, ListNode next) { this.val = val; this.next = next; }

    public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        int []value1 = new int[9];
        int []value2 = new int[9];
        int m=0;
        int n=0;
        while(l1 != null){
            value1[m++] = l1.val;
            l1= l1.next;
        }
        while(l2 != null){
            value2[n++] = l2.val;
            l2= l2.next;
        }
        int []result = new int[m];
        int []carry = new int[m];
        carry[0]=0;
        for(int i=0;i<m;i++){
            int res = value1[m-i-1] + value2[m-i-1] + carry[i];
            result[i] = res % 10;
            carry[i+1] = res / 10;
        }
        return l1;
    }
}
