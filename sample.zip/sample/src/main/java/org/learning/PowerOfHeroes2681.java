package org.learning;

import java.util.ArrayList;
import java.util.List;

public class PowerOfHeroes2681 {
    public static void main(String[] args) {
        System.out.println(sumOfPower(new int[]{2,1,4}));
    }
        public static int sumOfPower(int[] nums) {
            int n = nums.length;
            List<List<Integer>> combinations = new ArrayList<>();
            generateCombination(nums,0,n,combinations,new ArrayList<>());
            int res = 0;
            for(List<Integer> data:combinations){
                res += data.stream().mapToInt(Integer::intValue).sum();
            }
            return (res % 1000000007);
        }

        public static void generateCombination(int []nums,int i,int n,List<List<Integer>> result,List<Integer> formedSet){
            if(i == n){
                result.add(new ArrayList<>(formedSet));
                return;
            }
            //if value picked
            if(i < n){
                formedSet.add(nums[i]);
                generateCombination(nums,i+1,n,result,formedSet);
                formedSet.remove(formedSet.size()-1);

                //if value not picked
                generateCombination(nums,i+1,n,result,formedSet);
            }
        }
    }
