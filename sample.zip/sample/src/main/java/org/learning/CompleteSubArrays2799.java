package org.learning;

import java.util.*;
import java.util.stream.Collectors;

public class CompleteSubArrays2799 {
    public static void main(String args[]) {
        int x=10;
        int y=25;
        int z=x+y;

        System.out.println(countCompleteSubarrays(new int[]{5,5,5,5}));
    }
    public static int countCompleteSubarrays(int[] nums) {
        long value = Arrays.stream(nums).distinct().count();
        List<List<Integer>> result = new ArrayList<>();
        int v =  createSubArray(nums,0,value,new ArrayList<>(),result);
        System.out.println(result.stream().distinct().collect(Collectors.toList()));
        return (int)result.stream().distinct().count();
    }

    private static int createSubArray(int[] nums, int index, long value, List<Integer> subArray, List<List<Integer>> result1 ){
        if(index == nums.length){
            long distinctSubArray = subArray.stream().distinct().count();
            //System.out.println(subArray);
            if(distinctSubArray == value){
                List<Integer> s = new ArrayList<>(subArray);
                Collections.sort(s);
                result1.add(s);
                //subArray = new ArrayList<>();
                return 1;
            }
            else
                return 0;
        }

        int result = 0;
        if(index < nums.length){
            subArray.add(nums[index]);
            result += createSubArray(nums,index+1,value,subArray,result1);
            subArray.remove(subArray.size()-1);
            result += createSubArray(nums,index+1,value,subArray,result1);
        }
        return result;
    }

}