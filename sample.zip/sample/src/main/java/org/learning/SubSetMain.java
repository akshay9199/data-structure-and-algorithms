package org.learning;

import java.util.*;

public class SubSetMain {
    public static void main(String args[]){
       int []data = new int[]{4,5,6,7,1,2,3};
       List<List<Integer>> result = new ArrayList<>();
       findSubSets(0,data,5,result,new ArrayList<>());
        //Set<List<Integer>> da = new LinkedHashSet<>(result);
        System.out.println(result.toString());
    }











    public static void findSubSets(int index,int []data,int target,List<List<Integer>> result,List<Integer> ds){
        if(index == data.length){
            if(target == 0){
                result.add(new ArrayList<>(ds));
                return;
            }
            else return;
        }
        //if picked
        if(target >= data[index]){
            ds.add(data[index]);
            findSubSets(index+1,data,target-data[index],result,ds);
            ds.remove(ds.size()-1);
        }
        // won't picked
        findSubSets(index+1,data,target,result,ds);
    }
}
