package org.learning;

import java.util.ArrayList;
import java.util.List;

public class MinimumNumberOfJumps {
    public static void main(String[] args) {
        List<String> result = new ArrayList<>();
        System.out.println(minimumJumps(new int[]{2,3,1,1,4},0,5,result,""));
        System.out.println(result);
    }

    public static int minimumJumps(int [] value,int start,int end,List<String> result,String dp){
       if (start >= end)
       {
           return 0;
       }
       int min = Integer.MAX_VALUE;
       int localMin;
       for(int i=1;i<=value[start];i++){

           if(i < value.length){
               dp+=" "+value[start];
               localMin = 1+minimumJumps(value,start+i,end,result,dp);
               result.add(dp);
               if(localMin < min){
                   min = localMin;
               }
           }
       }
       return min;
    }
}
