package org.learning;

import java.util.*;

public class WaterPump {

    public static void main(String[] args) {
        System.out.println(find(new int[]{2,1,3,2,1,1},new int[]{0,3}));
    }
    public static int[] find(int []t,int []d){
        int n = t.length;
        int []result = new int[n];
        Arrays.fill(result,0);
        Queue<Node2> queue = new LinkedList<>();
        for(int i=0;i<d.length;i++){
            queue.add(new Node2(t[d[i]],d[i]));
        }
        //queue.add(new Node2(t[d[0]],d[0]));
        while(!queue.isEmpty()){
            Node2 node = queue.poll();
            if(node.index-1 >=0 && node.value > t[node.index-1] && result[node.index-1] != 1){
                queue.add(new Node2(node.value,node.index-1));
                result[node.index-1] = 1;
            }
            if(node.index+1 < n && node.value > t[node.index+1] && result[node.index+1] != 1){
                queue.add(new Node2(node.value,node.index+1));
                result[node.index+1] = 1;
            }
        }
        return result;
    }
}
class Node2 implements Comparator<Node2> {
    int value;
    int index;

    public Node2(int v,int i){
        value = v;
        index = i;
    }
    @Override
    public int compare(Node2 obj1, Node2 obj2) {
        if(obj1.value > obj2.value)
            return 1;
        else if(obj2.value > obj1.value)
            return -1;
        else return 0;
    }
}