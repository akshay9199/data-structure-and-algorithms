package org.learning;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CompletableFutureExample {
    public static void main(String[] args) {
        // Create a CompletableFuture that runs a task asynchronously
        CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> {
            // Simulate a long-running task
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "Hello, World!";
        });

        // Define what to do when the task completes
        future.thenAccept(result -> {
            System.out.println("Result: " + result);
        });

        // Wait for the CompletableFuture to complete
        try {
            future.get(); // This blocks the main thread until the result is available
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}
