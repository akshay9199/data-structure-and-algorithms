package org.learning;

import org.w3c.dom.ls.LSException;

import java.util.*;

public class GraphWithComponents {
    public static void main(String[] args) {
        List<List<Integer>> graph = new ArrayList<>();
        graph.add(Arrays.asList());
        graph.add(Arrays.asList(2));
        graph.add(Arrays.asList(1, 3));
        graph.add(Arrays.asList(2, 4));
        graph.add(Arrays.asList(3, 5));
        graph.add(Arrays.asList(4));
        graph.add(Arrays.asList());
        graph.add(Arrays.asList(9));
        graph.add(Arrays.asList(10));
        graph.add(Arrays.asList(7));
        graph.add(Arrays.asList(8));
        graph.add(Arrays.asList());
        graph.add(Arrays.asList(13));
        graph.add(Arrays.asList(12));
        Queue<Integer> queue = new LinkedList<>();
        queue.add(1);
        Set<Integer> visited = new HashSet<>();
        int max = 0;
        for(int i=1;i<graph.size();i++){
            int value = explore(graph.get(i),queue,visited);
            System.out.println(value);
            if(value > max){
                max = value;
            }
        }
        System.out.println("Max"+max);
    }

    public static int explore(List<Integer> graph,Queue<Integer> queue,Set<Integer> visited){
        if (queue.size() == 0) return 0;
        int value = queue.poll();
        visited.add(value);
        for(Integer neighbor:graph){
            if(!visited.contains(neighbor)){
                queue.add(neighbor);
                visited.add(neighbor);
            }
        }
        return 1+explore(graph,queue,visited);
    }
}

