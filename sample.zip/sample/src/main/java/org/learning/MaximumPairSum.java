package org.learning;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class PairT {
    int a;
    int b;
    public PairT(int a,int b){
        this.a = a;
        this.b = b;
    }
    public int getA(){
        return this.a;
    }
    public int getB(){
        return this.b;
    }
}
public class MaximumPairSum {
    public static int minPairSum(int[] nums) {
        int n = nums.length;
        List<PairT> record = new ArrayList<>();
        Arrays.sort(nums);
        int left = 0;
        int right = n-1;
        while(left<right){
            record.add(new PairT(nums[left],nums[right]));
            left++;
            right--;
        }
        int maxSum = Integer.MIN_VALUE;
        for(int i=0;i<record.size();i++){
            int value = record.get(i).a + record.get(i).b;
            maxSum = Math.max(maxSum,value);
        }
        return maxSum;
    }

    public static void main(String[] args) {
        System.out.println(minPairSum(new int[]{3,5,2,3}));
    }
}
