package org.learning;

import java.util.ArrayList;
import java.util.List;

public class StringMatchFound {
    public  static boolean checkStrings(String s1, String s2) {
        int []m = new int[4];
        int n = s1.length();
        boolean match = false;
        for(int i=0;i<n;i+=2){
            boolean matchFound = checkStringEqual(s1,s2,i,n);
            if(matchFound){
                match = true;
                break;
            }
        }
        for(int i=1;i<n;i+=2){
            boolean matchFound = checkStringEqual(s1,s2,i,n);
            if(matchFound){
                match = true;
                break;
            }

        };

        return match;
    }
    public static boolean checkStringEqual(String s1,String s2,int i,int n){
        if(s1.length() != s2.length())
            return false;
        boolean matchFound = false;
        for(int k=i+2;k<n;k+=2){
            char c1 = s1.charAt(i);
            char c2 = s1.charAt(k);
            StringBuilder t = new StringBuilder(s1);
            t.setCharAt(i,c2);
            t.setCharAt(k,c1);
            s1 = t.toString();
            if(s1.equals(s2)){
                matchFound = true;
                break;
            }
        }
        return matchFound;
    }

    public static void main(String[] args) {
        System.out.println(checkStrings("abcdba","cabdab"));
    }
}
