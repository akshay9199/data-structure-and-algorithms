package org.learning;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class DynamicProgrammingMain {
    public static void main(String[] args) {
        int m =6;
        int []value = new int[m+1];
        //int n = fibonacci(m);
        //Arrays.fill(value,-1);
        //int n = memoF(m,value);
       // int n = memoT(m);
        int n  = memoTW(m);
        System.out.println(n);
    }

    //Tabulation with space optimization
    public static int memoTW(int n){
        int prev2= 0;
        int prev1=1;
        int current = 0;
        for(int i=2;i<=n;i++){
            current = prev1+prev2;
            prev2 = prev1;
            prev1 = current;
        }
        return current;
    }

/*    Tabulation eliminates recursion altogether by iteratively filling a
    table from the smallest subproblems to the final solution. By sequentially
    calculating solutions and storing them in a table, we achieve both time
    and space complexity of O(n),
    as we only need to store the solutions for the previous two Fibonacci numbers.*/
    //Tabulation without optimization
    public static int memoT(int n){
        int []dp = new int[n+1];
        dp[0]= 0;
        dp[1]=1;
      for(int i=2;i<=n;i++){
          dp[i] = dp[i-1]+dp[i-2];
      }
      return dp[n];
    }



    //Memorization
    //time complexity to O(n) and space complexity to O(n)
    public static int memoF(int n,int []value){
        if(n<=1) return n;
        if(value[n] != -1) return value[n];
        return value[n] = memoF(n-1,value) + memoF(n-2,value);
    }


    //Recursion
    //time complexity of O(2^n)
    //Additionally, the space complexity is O(n) due to the recursive call stack
    public static int fibonacci(int n){
        if(n<=1) return n;
       return fibonacci(n-1) + fibonacci(n-2);
    }
}