package org.learning;

import java.util.HashMap;

public class NumberOfIslands {
    public int countIslands(int [][]graph){
        int row = graph.length;
        int col = graph[0].length;
        boolean [][]visited = new boolean[row][col];
        int count = 0;
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                if(graph[i][j] == 1 && !visited[i][j]){
                    //count all its neighbor;
                    exploreNeighbor(graph,i,j,visited);
                    count++;
                }
            }
        }
        return count;
    }
    public static void exploreNeighbor(int [][]m,int i,int j,boolean [][]visited){
        int []rowNeighbor = new int[]{0,1,1,1,0,-1,0,-1};
        int []colNeighbor = new int[]{1,1,0,-1,-1,-1,0,1};
        visited[i][j] = true;

        for(int k=0;k<8;k++){
            if(isSafe(m,i+rowNeighbor[k],j+colNeighbor[k],visited)){
                exploreNeighbor(m,i+rowNeighbor[k],j+colNeighbor[k],visited);
            }
        }
    }
        public static boolean isSafe(int [][]m,int row,int col, boolean [][]visited){
            return (row>=0 && row <m.length && col>=0 && col<m[0].length && m[row][col] == 1 && !visited[row][col]);
        }

    public static void main(String[] args) {
        int M[][] = new int[][] { { 1, 1, 0, 0, 0 },
                { 0, 1, 0, 0, 1 },
                { 1, 0, 0, 1, 1 },
                { 0, 0, 0, 0, 0 },
                { 1, 0, 1, 0, 1 } };
        NumberOfIslands I = new NumberOfIslands();
        System.out.println("Number of islands is: "
                + I.countIslands(M));
    }
    }

