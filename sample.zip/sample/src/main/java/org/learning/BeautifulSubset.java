package org.learning;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BeautifulSubset {

    public static void main(String args[]){
        beautifulSubsets(new int[]{590,136,844,976,670,485,794,114,434,82,245,673,738,416,252,1000,518,520,1,622},999);
    }
    public static int beautifulSubsets(int[] nums, int k) {
    List<List<Integer>> result = new ArrayList<>();
    subsets(0,k,nums,result,new ArrayList<>());
    result = result.stream().filter(data -> data.size() > 0).collect(Collectors.toList());
       // System.out.println(result.toString());
        return result.size();

    }

    public static void subsets(int index,int value, int []data, List<List<Integer>> result, List<Integer> ds){
        if(index == data.length){
            for(int i=0;i<ds.size();i++) {
                if (ds.contains(ds.get(i) + value)) {
                    return;
                }
            }

                result.add(new ArrayList<>(ds));
                return;
        }

        //pick
        if(index < data.length) {
            ds.add(data[index]);
            subsets(index + 1, value, data, result, ds);
            ds.remove(ds.size() - 1);
        }
        //not picked
        subsets(index+1,value,data,result,ds);
    }
}
