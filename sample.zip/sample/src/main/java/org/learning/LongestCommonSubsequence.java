package org.learning;

import java.util.Arrays;

public class LongestCommonSubsequence {
    public static void main(String[] args) {
        //System.out.println(findSub("abcaad","abcd",0,0));
        int [][] dp = new int["abcaad".length()]["abcd".length()];
        for(int i=0;i<"abcaad".length();i++){
            for(int j=0;j<"abcd".length();j++){
                dp[i][j] = -1;
            }
        }
        System.out.println(findSubMemo("abcaad","abcd",0,0,dp));

        // System.out.println(findSubString("abcaadef","abcdf",0,0));
    }
//    public static int findSubTabulation(String str1, String str2)
//    {
//        int []current = new int[str2.length()];
//        int []next = new int[str2.length()];
//        for(int i=str1.length()-1;i>=0;i--){
//            int ans0;
//            for(int j=str2.length()-1;j>=0;j--){
//                if(str1.charAt(i) == str2.charAt(j)){
//                    ans = 1 + findSub(str1,str2,i+1,j+1);
//                }
//                else
//                {
//                    ans = dpi+1,j),findSub(str1,str2,i,j+1));
//                }
//            }
//        }
//        if(i==str1.length() || j==str2.length()) return 0;
//        int len= 0;
//        if(dp[i][j] != -1) return dp[i][j];
//
//        dp[i][j] = len;
//        return dp[i][j];
//    }
//


    //Memoziation
    public static int findSubMemo(String str1, String str2, int i, int j,int [][] dp)
    {
        if(i==str1.length() || j==str2.length()) return 0;
        int len= 0;
        if(dp[i][j] != -1) return dp[i][j];
        if(str1.charAt(i) == str2.charAt(j)){
            len = 1+ findSub(str1,str2,i+1,j+1);
        }
        else
        {
            len = Math.max(findSub(str1,str2,i+1,j),findSub(str1,str2,i,j+1));
        }
        dp[i][j] = len;
        return dp[i][j];
    }


    //Recursion
    public static int findSub(String str1, String str2, int i, int j)
    {
        if(i==str1.length() || j==str2.length()) return 0;
        int len= 0;
        if(str1.charAt(i) == str2.charAt(j)){
            len = 1+ findSub(str1,str2,i+1,j+1);
        }
        else
        {
            len = Math.max(findSub(str1,str2,i+1,j),findSub(str1,str2,i,j+1));
        }
        return len;
    }

    public static String findSubString(String str1, String str2, int i, int j)
    {
        if(i==str1.length() || j==str2.length()) return "";
        String res = "";
        StringBuilder str = new StringBuilder();
        if(str1.charAt(i) == str2.charAt(j)){
            res = str1.charAt(i)+findSubString(str1,str2,i+1,j+1);
        }
        else
        {
            res = findSubString(str1,str2,i+1,j).length()>findSubString(str1,str2,i,j+1).length() ?
                    findSubString(str1,str2,i+1,j) : findSubString(str1,str2,i,j+1);
        }
        return res;
    }
}
