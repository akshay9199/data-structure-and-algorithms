package org.learning;

import java.util.*;

public class Graph{
    public static void main(String[] args) {
/*        List<List<Integer>> graph = new ArrayList<>();
        graph.add(Arrays.asList());
        graph.add(Arrays.asList(2));
        graph.add(Arrays.asList(1,3,4));
        graph.add(Arrays.asList(2,5,6));
        graph.add(Arrays.asList(2));
        graph.add(Arrays.asList(3));
        graph.add(Arrays.asList(3,7));
        graph.add(Arrays.asList(6));*/

        //exploreDFS(graph);
        //exploreBFS(graph);
        //Stack stack = new Stack();
        //stack.add(1);
        //exploreDFSWithRecursion(graph,stack, new HashSet());
        Queue queue = new LinkedList();
        queue.add(1);
        //exploreBFSWithRecursion(graph,queue, new HashSet());


        List<List<Integer>> graph = new ArrayList<>();
        graph.add(0,Arrays.asList(1));
        graph.add(1,Arrays.asList(0,2));
        graph.add(2,Arrays.asList(6,1));
        graph.add(3,Arrays.asList(2));
        graph.add(4,Arrays.asList(5));
        graph.add(5,Arrays.asList(4));
        graph.add(6,Arrays.asList(2));
        Set<Integer> visited = new HashSet<>();
       // Stack stack = new Stack();
       // stack.add(0);
        for(int i=0;i<graph.size();i++){
            Stack stack = new Stack();
            //int count = 0;
            stack.add(i);
            int c = exploreDFS(graph,visited,stack);
            System.out.println(c);
           System.out.println(visited.toString());
        }

    }

    public static int exploreDFS(List<List<Integer>> graph,Set<Integer> visited,Stack stack) {
        if (stack.size() == 0) return 0;
        int count = 0;
        int value = (int) stack.pop();
        count++;
        visited.add(value);
        for (Integer neighbor : graph.get(value)) {
            if (!visited.contains(neighbor)) {
                stack.add(neighbor);
                visited.add(neighbor);
                count++;
            }
        }
            exploreDFS(graph, visited, stack);
        return count;
    }




//    public static void exploreBFSWithRecursion(List<List<Integer>> graph,Queue<Integer> queue,Set<Integer> visited){
//    if(queue.size()==0) return;
//    int value = queue.poll();
//    visited.add(value);
//    System.out.println(value);
//    for(Integer neighbor:graph.get(value)){
//        if(!visited.contains(neighbor)){
//            queue.add(neighbor);
//            visited.add(neighbor);
//        }
//    }
//    exploreBFSWithRecursion(graph,queue,visited);
//
//    }




//
//    Steps of the Algorithm:
//    Base Case: The recursion terminates when the stack is empty.
//    Processing a Node:
//    The node at the top of the stack is popped.
//    It is added to the visited set and printed.
//    Exploring Neighbors:
//    Each neighbor of the current node is checked.
//    If a neighbor has not been visited, it is added to the stack and marked as visited.
//    Recursive Call: The function calls itself recursively to continue exploring.
//    Time Complexity:
//    To determine the time complexity, we need to consider both nodes and edges in the graph.
//
//    Nodes Processing:
//    Each node is processed once when it is popped from the stack.
//    In the worst case, all nodes are visited, resulting in O(V) operations where V is the number of vertices (nodes).
//    Edges Processing:
//    For each node, all its neighbors are iterated over.
//    Each edge is checked at most twice: once from each end (i.e., once for each node that is part of the edge).
//    This results in O(E) operations where E is the number of edges.
//    Combined Complexity:
//    The total time complexity is the sum of the time to process all nodes and the time to process all edges:
//    O(V)+O(E)=O(V+E)
//
//    Explanation:
//    O(V): Each node is visited exactly once.
//    O(E): Each edge is considered once for each of its two endpoints in an undirected graph, leading to O(2E), which simplifies to O(E).
//    Space Complexity:
//    The space complexity primarily depends on the data structures used:
//
//    Stack: In the worst case, the stack can hold all nodes, leading to O(V) space.
//    Visited Set: The visited set stores all nodes, resulting in O(V) space.
//    Call Stack: The recursion depth can go up to O(V) in the worst case, contributing to the space complexity.
//            Therefore, the space complexity is O(V).
//
//    Summary:
//    Time Complexity: O(V + E)
//    Space Complexity: O(V)
   public static void exploreDFSWithRecursion(List<List<Integer>> graph, Stack stack, Set visited){
        if (stack.size() == 0) return;
        int value = (int)stack.pop();
        visited.add(value);
        System.out.println(value);
        for(Integer neighbor:graph.get(value)){
            if(!visited.contains(neighbor)){
                stack.add(neighbor);
                visited.add(neighbor);
            }
        }
        exploreDFSWithRecursion(graph,stack,visited);

    }









    //BFS
    public static void exploreBFS(List<List<Integer>> graph){
        Set<Integer> visited  = new HashSet<>();
        Queue queue = new LinkedList();
        queue.add(1);
        visited.add(1);
        while(queue.size()>0){
            int value = (int) queue.poll();
            System.out.println(value);
            for(Integer neighbor:graph.get(value)){
                if(!visited.contains(neighbor)){
                    queue.add(neighbor);
                    visited.add(neighbor);
                }
            }
        }
    }

    //DFS
    public static void exploreDFS(List<List<Integer>> graph){
        Stack stack = new Stack();
        Set<Integer> visited = new HashSet<>();
        stack.push(1);
        visited.add(1);
        while(stack.size()>0){
            int value = (int) stack.pop();
            System.out.println(value);
            for(Integer neighbor: graph.get(value)){
                if(!visited.contains(neighbor)){
                    stack.push(neighbor);
                    visited.add(neighbor);
                }

            }
        }
    }

}