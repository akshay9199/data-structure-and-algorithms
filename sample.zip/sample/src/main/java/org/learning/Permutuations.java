package org.learning;

import java.util.ArrayList;
import java.util.List;
public class Permutuations {
    public static void main(String[] args) {
        String sample="sam";
        List<String> result = new ArrayList<>();
        generateSubString(sample,0,sample.length(), result, new ArrayList<>());
        System.out.println(result.toString());
    }

    public  static void generateSubString(String value,int index,int n,List<String> result, List<Character> dp){
       if(index == n){
           result.add(dp.toString());
           return;
       }
        //picked
        if(index<n) {
            dp.add(value.charAt(index));
            generateSubString(value, index + 1, n, result, dp);
            dp.remove(dp.size() - 1);
        }
        //notpicked
        generateSubString(value,index+1,n,result,dp);
    }
}
