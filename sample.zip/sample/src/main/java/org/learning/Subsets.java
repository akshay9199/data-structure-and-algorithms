package org.learning;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Subsets {
    public static void main(String args[]){
        int []data = new int[]{1,2,2};
        List<List<Integer>> result = new ArrayList<>();
        getSubsets(0,data, result, new ArrayList<>());
        Set<List<Integer>> dd = new LinkedHashSet<>(result);
        System.out.println(dd.toString());
    }
    public static void getSubsets(int index, int []data, List<List<Integer>> result, List<Integer> ds){
        if(index > data.length){
            result.add(new ArrayList<>(ds));
            return;
        }
//picked
        if(index < data.length) {
            ds.add(data[index]);
            getSubsets(index + 1, data, result, ds);
            ds.remove(ds.size() - 1);
        }
//not picked
        getSubsets(index+1,data,result,ds);

    }
}
